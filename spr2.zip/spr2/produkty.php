<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            background-color: lime;
            color: blue;
        }
        table{
            position: absolute;
            left: 30%;
            margin-left:20px;
            text-align: center;
            
        }
        
        td,th{
            border: 4px solid magenta;
            border-radius: 7px;
            padding: 3px;
            user-select: none;
            background-color: aqua;
        }

        form{
            position: absolute;
            margin-left: 20px;   
            border: 8px dashed magenta;
            padding: 10px;
        }
        input{
            margin: 5px;
            background-color: red;
            border: 3px solid yellow;
            padding: 3px;
            color: azure;
            font-weight: 100;
        }
        label{
            user-select: none;
        }
    </style>
</head>
<body>

<?php
$conn = @new mysqli('localhost', 'root', NULL, 'mj_produkty');
if($conn->connect_errno) die('Brak połączenia z mysql');
$conn->query('SET NAMES UTF8');
$przycisk = 'dodaj';
$nazwa = '';
$cena = '';
$ilosc = '';
$id = '';
if(isset($_GET['akcja'])){
    switch($_GET['akcja']){
    case 'dodaj':
        $nazwa = $_GET['nazwa'];
        $cena = $_GET['cena'];
        $ilosc = $_GET['ilosc'];
        $sql = "INSERT INTO produkty(nazwa, cena, ilosc) VALUES ('$nazwa', $cena, $ilosc)";
        $conn->query($sql) or die('nie działa');  
    break;
    case 'usun':
        if(isset($_GET['id'])){
            $id=$_GET['id'];
            $conn->query("DELETE FROM produkty WHERE id=$id");
        }
    break;
    case 'edytuj':
        if(isset($_GET['id'])){
            $id=$_GET['id'];
            $rs = $conn->query("SELECT nazwa, cena, ilosc FROM produkty WHERE id=$id") or die ("Nie mozna pobrac rekordu");
            $rec = $rs-> fetch_assoc();
            $nazwa = $rec['nazwa'];
            $cena = $rec['cena'];
            $ilosc = $rec['ilosc'];
            $przycisk = 'zapisz';         
        }
    break;
    case 'zapisz':
        if(isset($_GET['id'],$_GET['nazwa'],$_GET['cena'],$_GET['ilosc'])){
            $id=$_GET['id'];
            $nazwa = $_GET['nazwa'];
            $cena = $_GET['cena'];
            $ilosc = $_GET['ilosc'];
            $sql = "UPDATE produkty SET nazwa='$nazwa',cena=$cena,ilosc=$ilosc WHERE id=$id";
            $conn->query($sql) or die ('zapis nie działa');
            $nazwa = '';
            $cena = '';
            $ilosc = '';
        }
    break;
    } 
}

    echo '<table>';
    echo '<tr><th>Nazwa</th><th>Cena</th><th>Ilość</th><th>Usuwanie</th><th>Edycja</th></tr>';
    $rs=$conn->query('SELECT * FROM produkty');
    while($rec=$rs->fetch_assoc()){
        echo '<form><tr>
        <td><input type="hidden" name="id" value="',$rec['id'],'">', $rec['nazwa'],' </td>
        <td>',$rec['cena'], '</td>
        <td>',$rec['ilosc'],' </td>
        <td><input type="submit" name="akcja" value="usun"></td>
        <td><input type="submit" name="akcja" value="edytuj"></td>
        </tr></form>';
    }
    
    echo '</table>';
    echo "<br><br>
    <form>
        <input type='hidden' name='id' value='$id'>
        <label for='nazwa'>Nazwa: </label>
        <input type='text' id='nazwa' name='nazwa' value='$nazwa'><br>
        <label for='cena'>Cena: </label>
        <input type='text' id='cena' name='cena' value='$cena'><br>
        <label for='ilosc'>Ilość: </label>
        <input type='text' id='ilosc' name='ilosc' value='$ilosc'><br>
        <input type='submit'  name='akcja' value='$przycisk'>
    </form>";

    $rs->close();
    $conn->close();
?>


</body>
</html>