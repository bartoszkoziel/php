<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    form{
        display: flex;
        flex-direction: column;

    }
    </style>
</head>
<body>
    <?php
        $conn=new mysqli('localhost',"root","","jkasprzyk");
        if($conn->connect_error) die('Nie udało się połączyć z SQL');
else{


    $liczbaLogowan =  $conn->query("SELECT * FROM dzien");
    echo "<h1> Jaki jest twoj ulubiony dzien tygodnia :";
    echo $liczbaLogowan->fetch_assoc()["dzien"];
    echo    "</h1>";


    echo "<form method='post'>";
        while($input = $names_result->fetch_assoc()) {
        echo "<input type='radio' name='dzien' value='".$input["dzien"]."'>";
        echo $input["dzien"]."</br>"
    };

    echo "<button type='submit'>Wyślij</button>";
    echo "</form>";


    if(isset($_POST["dzien"])){
        echo "wybrany dzień " .$_POST["dzien"];
        echo "</br>";
         $request = "UPDATE days SET value = value + 1 WHERE name = '".$_POST["dzien"]."';";
        $conn->query($request);
    }

    echo "<img src='http://localhost/mmetel/rysunek.php%27/%3E";
}W
    ?>

</body>
</html>