<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            background-color: lightblue;
        }
    </style>
</head>
<body>
    <h3>Jaki jest twój ulubiony dzień tygodnia?</h3>
<?php
    $conn = @new mysqli('localhost','root',NULL,'mjanuszek');
    
    if($conn->connect_errno) die('Brak połączenia z mysql');
    $conn->query('SET NAMES UTF8');

    
    if(isset($_GET['radio'])){
        $dzien = $_GET['radio'];
        $conn->query("UPDATE tydzien SET licznik=licznik + 1 WHERE dzien = '$dzien'");
    }
    
    
    
    $rs = $conn->query('SELECT * FROM tydzien');
    
    echo "<form>";

    while($rec = $rs->fetch_assoc()){
        echo '<input type="radio" id="',$rec['id'],'" name="radio" value="',$rec['dzien'],'">';
        echo '<label for="',$rec['id'],'">',$rec['dzien'],'</label>';
        echo "<br>";
    }
    echo "<br>";
    echo "<input type='submit' value='send'>";
    echo "</form>";

    $rs->close();
    $conn->close();
?>
<br>
<img src="wykres.php" height="400px" />
</body>
</html>