<?php
		header("Content-type: image/jpeg");
		$rysunek = imagecreate (500,500) ;
		$kolorbialy = imagecolorallocate ($rysunek, 255,255,255);
		$kolorczarny = imagecolorallocate ($rysunek, 0, 0, 0);
		imagefill($rysunek, 0, 0, $kolorbialy);

		$mysqli = new mysqli('localhost','root',NULL,'mjanuszek');
		$ok3 = $mysqli->prepare("SELECT `id`,`dzien`,`licznik` FROM `tydzien`");
		$ok3->execute();
        $result = $ok3->get_result();

		$i = 0;
		$suma = 0;

		while($row = $result->fetch_assoc())
		{
			$kolorslupka = imagecolorallocate ($rysunek, 25*$i, 25*$i,0);
			imagefilledrectangle ($rysunek, 150, $i*50+5, $row['licznik']*30+150, $i*50+20, $kolorslupka);
			imagestring ($rysunek, 7, 10, $i*50, $row["dzien"], $kolorczarny);
			imagestring ($rysunek, 7, $row['licznik']*30+160, $i*50+5, $row['licznik'], $kolorczarny);
			$i++;
			$suma += $row['licznik'];
		}

		imagestring ($rysunek, 7, 10, 480, "Wszystkich glosow jest: ".$suma, $kolorczarny);
		imagejpeg($rysunek);
?>