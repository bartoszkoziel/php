<?php
    $mysqli = new mysqli('localhost','root',NULL,'mjanuszek');

    if(isset($_POST['radio']))
    {
        $ok = $mysqli->prepare("SELECT name, count FROM `tydzien` WHERE id=?");
        $ok->bind_param("i",$_POST['radio']);
		$ok->execute();
        $result = $ok->get_result();

        if($row = $result->fetch_assoc()){
            $count = $row['count'];
            $count += 1;
            echo $count;

            $ok2 = $mysqli->prepare("UPDATE tydzien SET count=? WHERE id=?");
            $ok2->bind_param("ii",$count, $_POST['radio']);
            $ok2->execute();
            $result = $ok2->get_result();
            $ok2->close();
        }
        $ok->close();
    }

    $ok3 = $mysqli->prepare("SELECT `id`, `name`FROM `tydzien`");
    $ok3->execute();
    $result = $ok3->get_result();
		
    echo "<form method='POST'>";
    while($row = $result->fetch_assoc())
    {
        echo $row['name']." <input type='radio' name='radio' value='".$row['id']."'><br/>";
    }
	echo "<input type='submit' value='send' /></form>";
    $ok3->close();
    $mysqli->close();
?>

<img src="wykres.php" height="400px" />